
var app = angular.module("app", []);
app.controller("ctrl", function($scope) {
		$scope.txt_head = "Age Calculator";
		$scope.year = 1994;
		$scope.text = function(){
			return "You are  "  + (2018 - $scope.year) + " Years old";
		};
});

app.controller("cal", function($scope) {
		$scope.txt_head = "Calculator";
		$scope.num1 = 10;
		$scope.num2 = 2;
		$scope.calc = "sum";
		$scope.result = function(){
			switch($scope.calc){
				case "sum": 
					return $scope.num1 + $scope.num2;
				case "subtract": 
					return $scope.num1 - $scope.num2;
				case "multiply": 
					return $scope.num1 * $scope.num2;
				case "divide": 
					return $scope.num1 / $scope.num2;
			}
		};
});

app.controller("filtrationctrl", function($scope) {
		$scope.txt_head = "Filteration";
		$scope.fil = "";
		$scope.people = [
			{name: "Abel", surname: "Makukule"},
			{name: "Andile", surname: "Hlophe"},
			{name: "Ntshovelo", surname: "Makwarela"},
			{name: "Siyasanda", surname: "Ndongeni"},
		];
});

app.controller("imageshow", function($scope) {
	$scope.txt_head = "Shopping Cart";
	$scope.qty = 0;
	$scope.total = 0.0;
	$scope.tot_qty = 0;
	$scope.show_images = false;
	$scope.calcTotal = function(f, qty){
		$scope.total = $scope.total + qty * f.price;
		$scope.tot_qty = $scope.tot_qty + qty;
	}
	$scope.fruits = [
		{name: "Apple", path: "images/apple.jpg",price: 3.20},
		{name: "Banana", path: "images/banana.jpg",price: 2.00},
		{name: "Peach", path: "images/peach.jpg",price: 1.50},
		{name: "Orange", path: "images/orange.jpg",price: 4.00}
	];
});

app.controller("listctrl", function($scope){
	$scope.txt_head = "Item List";
	$scope.txt_btn_add= "Add";
	$scope.txt_btn_clr= "Clear";
	$scope.item = "";
	$scope.error = {msg: "", style: {'color': 'green'}};
	var default_size = '12';
	$scope.items = [
			{fruit: "Apple", color: "gray", font: "plain", size: default_size},
			{fruit: "Banana", color: "gray", font: "plain", size: default_size},
			{fruit: "Orange", color: "gray", font: "plain", size: default_size},
		];
	$scope.count = $scope.items.length;
	$scope.addItem = function(item){
		var found = $scope.items.find(function(element) { 
			if(element.fruit == item){
				return item;
			}
		});
		
		try{
			var test_case = found.fruit == item;
		}
		catch(err){
			if(item.length > 2 && item.length < 11){
				$scope.items[$scope.items.length] = {fruit: item, color: "gray", font: "plain", size: default_size};
				$scope.count = $scope.items.length;
				$scope.item = "";
				$scope.error.msg = "";
			}
		}
	}
	$scope.clear = function(){
		$scope.items = [];
		$scope.count = $scope.items.length;
	}
	
	$scope.deleteItem = function(index){
		$scope.items.splice(index, 1);
		$scope.count = $scope.items.length;
		$scope.typing($scope.item);
	}
	
	$scope.highlight= function(index){
		$scope.items[index].color = '#2373C3';
		$scope.items[index].font = 'bold'
		$scope.items[index].size = '17'
	}
	$scope.lowlight= function(index){
		$scope.items[index].color = 'gray';
		$scope.items[index].font = 'plain'
		$scope.items[index].size = default_size
	}
	$scope.typing = function(item){
		var found = $scope.items.find(function(element) { 
			if(element.fruit == item){
				return item;
			}
		});
		
		try{
			var test_case = found.fruit == item;
			$scope.error = {msg: "Already exists!", style: {'color': '#C3235E'}};
		}
		catch(err){
			if(item.length > 2 && item.length < 11){
				$scope.error = {msg: "Perfect!", style: {'color': '#0A9016'}};
			}
			else{
				if(item.length < 10){
					$scope.error = {msg: "Too Short!", style: {'color': '#C3235E'}};
				}
				else{
					$scope.error = {msg: "Too Long!", style: {'color': '#C3235E'}};
				}
			}
		
		}	
	}
});

app.controller("timerctrl", function($scope, $interval) {
	$scope.show_inputs = true;
	$scope.timer_check = true;
	$scope.stopwatch_check = false;
	
	$scope.txt_head = "Timer/Stopwatch";
	$scope.txt_btn_start_stop = "Start";
	$scope.sec = 0;
	$scope.min = 0;
	$scope.hr = 0;
	
	var interval_fn = function(){
		if($scope.timer_check){
			if($scope.sec > 0 || $scope.min > 0 || $scope.hr > 0){
				if($scope.sec > 0){
					$scope.sec--;
				}
				else{
					$scope.sec = 59;
					if($scope.min > 0){
						$scope.min--;
					}
					else{
						$scope.min = 59;
						$scope.hr--;
					}
				}
			}
			else{
				$scope.start_stop();
			}
		}
		else{
			if($scope.sec < 59){
				$scope.sec++;
			}
			else{
				$scope.sec = 0;
				if($scope.min < 59){
					$scope.min++;
				}
				else{
					$scope.min = 0;
					$scope.hr++;
				}
			}	
		}
		
		
	}
	var interval;
	
	$scope.start_stop = function(){
		if($scope.txt_btn_start_stop == "Start"){
			$scope.txt_btn_start_stop = "Stop";
			if($scope.show_inputs == true){
				$scope.show_inputs = false;
				if(!($scope.min < 60)){
					$scope.min = 0;
				}
				if(!($scope.sec < 60)){
					$scope.sec = 0;
				}
			}
			
			
			interval = $interval(interval_fn , 1000);
		}
		else{
			$scope.txt_btn_start_stop = "Start";
			$scope.show_inputs = true;
			$interval.cancel(interval);
		}
	}
	$scope.doubleUp = function(val){
		if(val < 10){
			return '0' + val;
		}
		else{
			return '' + val;
		}
	}
	$scope.clock = function(){
		return $scope.doubleUp($scope.hr) 
				+ ':' + $scope.doubleUp($scope.min) 
				+ ':' + $scope.doubleUp($scope.sec);
	};
	$scope.switch_check = function(){
		if($scope.timer_check){
			$scope.timer_check = false;
			$scope.stopwatch_check = true;
		}
		else{
			$scope.timer_check = true;
			$scope.stopwatch_check = false;
		}
	}
});

app.controller("httpctrl", function($scope, $http){
	$scope.txt_head = "Http";
	 $http.get("welcome.htm")
    .then(function(response) {
        $scope.myWelcome = response.data;
    });
});